#!/usr/bin/env python

from distutils.core import setup

setup(name='ai42',
      version='1.0',
      description='My python library',
      author='cchudant',
      author_email='cchudant@student.42.fr',
      url='https://42.fr',
     )
